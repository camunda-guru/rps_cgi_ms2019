package com.cgi.banking.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cgi.banking.models.Customer;
//import com.cgi.banking.models.CustomerNoSQL;
import com.cgi.banking.services.CustomerService;

@RestController
public class CustomerController {

	@Autowired
	private CustomerService service;
	
	@CrossOrigin("*")
	@PostMapping("/addcustomer")
	public @ResponseBody Customer addCustomer(@RequestBody Customer customer)
	{
		 return service.addCustomer(customer);
	}
	
	
	@CrossOrigin("*")
	@GetMapping("/getcustomers")
	public List<Customer> getAllCustomers()
	{
		 return service.getAllCustomers();
	}
	
	@CrossOrigin("*")
	@GetMapping("/getcustomerbyid/{mobileNo}")
	public Customer getCustomerById(@PathVariable("mobileNo") long mobileNo)
	{
		 return service.getCustomerByMobileNo(mobileNo);
	}
	
	@CrossOrigin("*")
	@DeleteMapping("/deletecustomerbyid/{id}")
	public void deleteCustomerById(@PathVariable("id") long id)
	{
		  service.deleteCustomer(id);
	}
	@CrossOrigin("*")
	@PutMapping("/updatecustomerbyid/{id}")
	public Customer updateCustomerById(@PathVariable("id") long id,@RequestBody Customer cust)
	{
		  Customer obj=service.getCustomerById(id);
		  obj.setFirstName(cust.getFirstName());
		  obj.setLastName(cust.getLastName());
		  obj.setDob(cust.getDob());
		  obj.setAddress(cust.getAddress());
		  return service.addCustomer(obj);
		  
	}
	
	
}
